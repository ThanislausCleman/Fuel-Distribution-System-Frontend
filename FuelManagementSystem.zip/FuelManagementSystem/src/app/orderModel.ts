export class OrderModel {
    orderId!:number;
    gasStationName!:string;
    gasStationId!:string;
    amount!:number;
    fuelType!:string;
    status!:string;
    date!:string;


}
