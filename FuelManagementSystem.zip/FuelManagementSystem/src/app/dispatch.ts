export class Dispatch {
    orderId!:number;
    date!:string;
}
